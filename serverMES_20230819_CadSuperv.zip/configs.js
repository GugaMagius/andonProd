
const connSuperv = "Data Source=MGU-SERVER02;Initial Catalog=SUPERVISORIO;User ID=gustavo;Password=magius@2021"

module.exports.connSuperv = connSuperv

const connMES = "Data Source=srvmes;Initial Catalog=PCF4;User ID=supervisorio;Password=magius"

module.exports.connMES = connMES

const email = {
    user: 'alerta@magius.com.br',
    pass: 'Magius1@'
}
module.exports.email = email