var dadosCompl = {

}

module.exports.dadosCompl = dadosCompl
