# andonecoat

## Observações

Necessário substituir o arquivo vue-sockeio.js no modulo vue-socketio/dist, caso contrário, irá apresentar erro e a tela não será apresentada.
O arquivo funcional está na raiz deste projeto.

Att: Gustavo

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


